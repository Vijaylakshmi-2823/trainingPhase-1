using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RazorWebsite.Pages
{
    public class AboutUsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
